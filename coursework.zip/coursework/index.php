<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

include 'includes/DatabaseConnection.php'; // Ensure your database connection is loaded

// Fetch the posts from the database with user and module information, ordered by id in descending order
$stmt = $pdo->query("SELECT posts.*, users.username, modules.name AS module FROM posts
                     JOIN users ON posts.user_id = users.id
                     JOIN modules ON posts.module_id = modules.id
                     ORDER BY posts.created_at DESC"); // Order by created_at in descending order, or use 'id'

$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// include the layout template where the $posts array will be used
include 'templates/layout.html.php';
?>
