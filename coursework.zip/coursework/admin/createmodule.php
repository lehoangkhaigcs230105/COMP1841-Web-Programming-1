<?php
include '../includes/DatabaseConnection.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_module'])) {
        // Sanitize the module name input
        $module_name = filter_input(INPUT_POST, 'module_name', FILTER_SANITIZE_STRING);

        if (!empty($module_name)) {
            // Insert the new module into the database
            $stmt = $pdo->prepare("INSERT INTO modules (name) VALUES (?)");
            $stmt->execute([$module_name]);

            // Redirect to prevent duplicate submissions
            header('Location: createmodule.php');
            exit();
        }
    }

    if (isset($_POST['delete_module'])) {
        // Sanitize and validate the module ID
        $module_id = filter_input(INPUT_POST, 'module_id', FILTER_VALIDATE_INT);

        if ($module_id) {
            try {
                // Delete the module from the database
                $stmt = $pdo->prepare("DELETE FROM modules WHERE id = ?");
                $stmt->execute([$module_id]);

                // Redirect after deletion
                header('Location: createmodule.php');
                exit();
            } catch (Exception $e) {
                echo "Error deleting module: " . $e->getMessage();
            }
        }
    }

    if (isset($_POST['edit_module'])) {
        // Sanitize and validate the module inputs
        $module_id = filter_input(INPUT_POST, 'module_id', FILTER_VALIDATE_INT);
        $module_name = filter_input(INPUT_POST, 'module_name', FILTER_SANITIZE_STRING);

        if ($module_id && !empty($module_name)) {
            try {
                // Update the module in the database
                $stmt = $pdo->prepare("UPDATE modules SET name = ? WHERE id = ?");
                $stmt->execute([$module_name, $module_id]);

                // Redirect after update
                header('Location: createmodule.php');
                exit();
            } catch (Exception $e) {
                echo "Error updating module: " . $e->getMessage();
            }
        }
    }
}

// Fetch the list of existing modules from the database
$modules = $pdo->query("SELECT * FROM modules ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

include '../templates/createmodule.html.php'; // Include the HTML template
?>
