<?php
include '../includes/DatabaseConnection.php';

// Get the module ID from the query string
$module_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$module_id) {
    echo "Invalid module ID.";
    exit();
}

// Fetch the module details from the database
$stmt = $pdo->prepare("SELECT * FROM modules WHERE id = ?");
$stmt->execute([$module_id]);
$module = $stmt->fetch();

if (!$module) {
    echo "Module not found.";
    exit();
}

// Handle the form submission to update the module
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $module_name = filter_input(INPUT_POST, 'module_name', FILTER_SANITIZE_STRING);

    if (!empty($module_name)) {
        $stmt = $pdo->prepare("UPDATE modules SET name = ? WHERE id = ?");
        $stmt->execute([$module_name, $module_id]);

        // Redirect after update
        header('Location: createmodule.php');
        exit();
    }
}

include '../templates/editmodule.html.php';
?>
