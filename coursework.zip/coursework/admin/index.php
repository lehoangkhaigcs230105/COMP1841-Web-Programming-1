<?php
session_start();
include '../includes/DatabaseConnection.php'; // Ensure your database connection is loaded

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

// Fetch the posts from the database
$stmt = $pdo->query("SELECT posts.*, users.username, modules.name as module FROM posts 
                     JOIN users ON posts.user_id = users.id 
                     JOIN modules ON posts.module_id = modules.id
                     ORDER BY posts.id DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'C:\xampp\htdocs\coursework\templates\admin_layout.htm.php'; // Include the admin page layout
?>
