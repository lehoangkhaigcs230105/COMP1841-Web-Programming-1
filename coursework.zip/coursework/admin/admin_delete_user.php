<?php
include '../includes/DatabaseConnection.php';

// Check if a user ID has been sent for deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete']) && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Prepare and execute the deletion
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);

    // Redirect back to the admin page after deletion
    header('Location: admin_delete_user.php');
    exit();
}

// Retrieve all users to display in the admin panel
$users = $pdo->query("SELECT id, username, email FROM users")->fetchAll(PDO::FETCH_ASSOC);

include '../templates/admin_delete_user.html.php';
?>
