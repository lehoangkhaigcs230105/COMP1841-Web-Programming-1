<?php
session_start();
include '../includes/DatabaseConnection.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

// Validate and sanitize the post ID from the GET request
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    echo "Invalid post ID.";
    exit();
}

// Fetch the post from the database
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the post exists
if (!$post) {
    echo "Post not found.";
    exit();
}

// Check if the logged-in user has the permission to edit (only user_id = 5 is allowed)
if ($_SESSION['user_id'] != 5) {
    echo "You do not have permission to edit this post.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input data
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
    $module_id = filter_input(INPUT_POST, 'module_id', FILTER_VALIDATE_INT);

    // Handle image upload
    $imagePath = $post['image']; // Default to the existing image
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        // Validate and upload the image
        $uploadDir = 'image/';
        $uploadFile = $uploadDir . basename($_FILES['image']['name']);

        // Check if the directory exists and create it if it doesn't
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Move the uploaded file and update image path if successful
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            $imagePath = basename($_FILES['image']['name']); // Save only the file name to the database
        }
    }

    // Update the post in the database
    $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, module_id = ?, image = ? WHERE id = ?");
    $stmt->execute([$title, $content, $module_id, $imagePath, $id]);

    header('Location: index.php');
    exit();
}

// Fetch modules for dropdown
$modules = $pdo->query("SELECT * FROM modules")->fetchAll(PDO::FETCH_ASSOC);
include '../templates/editpost.html copy.php';
?>
