<?php
include '../includes/DatabaseConnection.php';

// Get the user ID from the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch user information based on the ID
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    // Check if the user exists
    if (!$user) {
        echo "User not found";
        exit();
    }
} else {
    echo "Invalid request";
    exit();
}

// Update user information if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!empty($password)) {
        // Hash the new password before saving it
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
        $stmt->execute([$username, $email, $hashedPassword, $id]);
    } else {
        // Update username and email only, keep the password unchanged
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        $stmt->execute([$username, $email, $id]);
    }

    // Redirect to admin_delete_user.php after updating
    header('Location: admin_delete_user.php');
    exit();
   
}
include '../templates/updateuser.html.php';
?>