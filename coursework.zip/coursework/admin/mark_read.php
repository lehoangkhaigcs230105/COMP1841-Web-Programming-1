<?php
session_start();
include '../includes/DatabaseConnection.php';



// Check if the ID is set in the form
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Update the message to mark it as read
    $stmt = $pdo->prepare("UPDATE user_messages SET is_read = TRUE WHERE id = ?");
    $stmt->execute([$id]);

    // Redirect to the admin messages page after marking as read
    header('Location: contact.php');
    exit();
} else {
    // Redirect if ID is not set
    header('Location: contact.php');
    exit();
}