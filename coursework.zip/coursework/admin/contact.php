<?php
include '../includes/DatabaseConnection.php';

// Retrieve all messages, both read and unread, ordered by submission time
$stmt = $pdo->query("SELECT * FROM user_messages ORDER BY submitted_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'C:\xampp\htdocs\coursework\templates\contact.html copy.php';
?>
