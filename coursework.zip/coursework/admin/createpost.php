<?php
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include '../includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $user_id = $_SESSION['user_id']; // Set user_id from session
    $module_id = $_POST['module_id'];
    
    $image = '';
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        $image = basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $image;
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    }

    // Prepare and execute the post insertion query
    $stmt = $pdo->prepare("INSERT INTO posts (title, content, image, user_id, module_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$title, $content, $image, $user_id, $module_id]);

    header("Location: index.php");
    exit();
}

// Fetch modules for the module dropdown
$modules = $pdo->query("SELECT * FROM modules")->fetchAll(PDO::FETCH_ASSOC);

// Include the form template
include 'C:\xampp\htdocs\coursework\templates\createpost.html copy.php';
?>
