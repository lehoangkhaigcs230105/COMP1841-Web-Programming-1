<?php
include 'includes/DatabaseConnection.php'; // Ensure database connection is loaded

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve the user from the database based on email
    $sql = "SELECT * FROM users WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Password is correct, start a session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['module_id'] = $user['module_id'];

        // Redirect to a dashboard or homepage after successful login
        header('Location: index.php');
        exit();
    } else {
        echo "Invalid email or password.";
    }
}
include 'templates/login.html.php';

?>
