<?php
include 'includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hash the password for security

    // Insert the data into the users table
    $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'username' => $username,
        'email' => $email,
        'password' => $password
    ]);

    if ($stmt) {
        echo "Registration successful! You can now <a href='login.php'>login</a>";
    } else {
        echo "Error during registration. Please try again.";
    }
}

include 'templates/register.html.php';
?> 
