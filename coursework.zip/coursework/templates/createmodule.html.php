<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Module</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

<div class="container">
    <h1>Manage Module</h1>
    <form method="POST">
        <label for="module_name">Module Name</label>
        <input type="text" id="module_name" name="module_name" required>
        <button type="submit" name="create_module" class="btn">Create Module</button>
    </form>

    <h2>Existing Modules</h2>
    <ul>
        <?php foreach ($modules as $module): ?>
            <li>
                <?php echo htmlspecialchars($module['name']); ?>
                <!-- Delete Form -->
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="module_id" value="<?php echo $module['id']; ?>">
                    <button type="submit" name="delete_module" class="btn delete-btn">Delete</button>
                </form>
                <!-- Edit Button -->
                <form method="GET" action="editmodule.php" style="display: inline;">
                    <input type="hidden" name="id" value="<?php echo $module['id']; ?>">
                    <button type="submit" class="btn edit-btn">Edit</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>

    <a href="index.php" class="btn">Back to Home</a>
</div>

</body>
</html>
