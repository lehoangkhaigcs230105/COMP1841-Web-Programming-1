<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Forum</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="container">
        <h1>admin page</h1>
        <a href="createpost.php" class="btn">Create New Post</a>
        <a href="createmodule.php" class="btn">Manage module </a>
        <a href="contact.php" class="btn">Contact here </a>
        <a href="admin_delete_user.php" class="btn">Manage users </a>
        <a href="logout.php" class="btn">Logout</a>






        <div class="posts">
            <?php foreach ($posts as $post): ?>
                <div class="post">
                    <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                    <p><?php echo htmlspecialchars($post['content']); ?></p>
                    <p><strong>Author:</strong> <?php echo htmlspecialchars($post['username']); ?></p>
                    <p><strong>Module:</strong> <?php echo htmlspecialchars($post['module']); ?></p>
                    <?php if ($post['image']): ?>
                        <img height="100px" src="../image/<?= htmlspecialchars($post['image'], ENT_QUOTES, 'UTF-8'); ?>"/>
                    <?php endif; ?>
                    <a href="editpost.php?id=<?php echo $post['id']; ?>" class="btn">Edit</a>
                    <a href="deletepost.php?id=<?php echo $post['id']; ?>" class="btn">Delete</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>