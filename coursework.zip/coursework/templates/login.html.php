<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="login">
        <!-- <h2>Login</h2> -->
        <p>Don't have an account? <a href="register.php" class="btn">Sign up</a></p>
        <form class="login" action="login.php" method="POST">
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>

            <input type="submit" name="login" value="Login">
        </form>
    </div>    
    
</body>
</html>
