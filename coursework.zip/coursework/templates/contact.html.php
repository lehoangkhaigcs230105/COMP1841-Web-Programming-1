<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Contact Admin</h1>

        <!-- Show feedback message after submission -->
        <?php if (!empty($feedback)): ?>
            <p class="feedback"><?php echo htmlspecialchars($feedback); ?></p>
        <?php endif; ?>

        <!-- Contact form for submitting message -->
        <form action="contact.php" method="post">
            <!-- User Email Field -->
            <label for="email">Your Email:</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user_email); ?>" required>

            <!-- Message Field -->
            <label for="message">Your Message:</label>
            <textarea name="message" id="message" rows="5" required></textarea>
            
            <button type="submit" class="btn">Send Message</button>
        </form>

        <!-- Back Button -->
        <br>
        <a href="index.php" class="btn">Back to Home</a>
    </div>
</body>
</html>
