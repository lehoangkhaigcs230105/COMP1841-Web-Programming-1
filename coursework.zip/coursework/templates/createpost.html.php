<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Create a New Post</h1>
        <form action="createpost.php" method="POST" enctype="multipart/form-data">
            <label for="title">Title</label>
            <input type="text" id="title" name="title" required>
            
            <label for="content">Content</label>
            <textarea id="content" name="content" required></textarea>
            
            <label for="image">Upload Image</label>
            <input type="file" id="image" name="image">

            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">

            <label for="module">Select Module</label>
            <select id="module" name="module_id">
                <?php foreach ($modules as $module): ?>
                    <option value="<?php echo $module['id']; ?>"><?php echo htmlspecialchars($module['name']); ?></option>
                <?php endforeach; ?>
            </select>
            
            <button type="submit" class="btn">Create Post</button>
            <a href="index.php" class="btn">Back to Home</a>
        </form>
    </div>
</body>
</html>