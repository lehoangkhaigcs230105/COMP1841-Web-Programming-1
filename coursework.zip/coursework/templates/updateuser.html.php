<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update User</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <h2>Update User</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required />

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required />

        <label for="password">Password (leave blank to keep current password):</label>
        <input type="password" name="password" />

        <button type="submit">Update</button>
        <a href="index.php" class="btn">Back to Home</a>

    </form>
</body>
</html>
