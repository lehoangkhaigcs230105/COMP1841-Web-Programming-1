<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

<div class="container">
    <h1>Edit Post</h1>
    <form method="POST" enctype="multipart/form-data"> <!-- Added enctype for file upload -->
        
        <!-- Title -->
        <label for="title">Title</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($post['title']) ?>" required>

        <!-- Content -->
        <label for="content">Content</label>
        <textarea id="content" name="content" required><?= htmlspecialchars($post['content']) ?></textarea>

        <!-- Display the logged-in user's name -->
        <label>User</label>
        <p><strong><?= htmlspecialchars($_SESSION['username']) ?></strong></p>

        <!-- Module dropdown -->
        <label for="module_id">Module</label>
        <select id="module_id" name="module_id">
            <?php foreach ($modules as $module): ?>
                <option value="<?= $module['id'] ?>" <?= $post['module_id'] == $module['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($module['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <!-- Image display and upload -->
        <label for="image">Image</label>
        <?php if (!empty($post['image']) && file_exists("image/" . $post['image'])): ?>
            <img src="image/<?= htmlspecialchars($post['image']) ?>" alt="Post Image" style="max-width: 200px; margin-bottom: 10px;">
        <?php else: ?>
            <p>No image available</p>
        <?php endif; ?>
        <input type="file" id="image" name="image" accept="image/*">

        <!-- Submit button -->
        <button type="submit" class="btn">Update Post</button>
        <a href="index.php" class="btn">Back to Home</a>
    </form>
</div>

</body>
</html>