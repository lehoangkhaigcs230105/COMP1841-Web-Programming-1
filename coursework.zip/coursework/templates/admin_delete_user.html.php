<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin -Manage User</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <h2>Admin - Manage User</h2>
    <table>
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Actions</th> <!-- Rename the column to "Actions" -->
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td>
                        <!-- Form to delete user -->
                        <form action="admin_delete_user.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?');" style="display: inline;">
                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                            <button type="submit" name="delete">Delete</button>
                        </form>
                        <!-- Edit button redirects to updateuser.php -->
                        <a href="updateuser.php?id=<?= $user['id'] ?>" style="margin-left: 10px;">
                            <button type="button">Edit</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
