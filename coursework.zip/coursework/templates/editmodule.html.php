<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Module</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

<div class="container">
    <h1>Edit Module</h1>
    <form method="POST">
        <label for="module_name">Module Name</label>
        <input type="text" id="module_name" name="module_name" value="<?php echo htmlspecialchars($module['name']); ?>" required>
        <button type="submit" class="btn">Save Changes</button>
    </form>
    <a href="createmodule.php" class="btn">Cancel</a>
</div>

</body>
</html>
