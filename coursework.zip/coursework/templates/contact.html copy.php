<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Messages</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="container">
        <h1>Admin - Messages</h1>
        
        <?php if (empty($messages)): ?>
            <p>No messages to display.</p>
        <?php else: ?>
            <?php foreach ($messages as $message): ?>
                <div class="message" style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
                    <p><strong>From:</strong> <?php echo htmlspecialchars($message['email']); ?></p>
                    <p><strong>Message:</strong><br><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                    <p><small>Submitted on: <?php echo $message['submitted_at']; ?></small></p>
                    
                    <?php if (!$message['is_read']): ?>
                        <!-- Display the "Mark as Read" button only for unread messages -->
                        <form action="mark_read.php" method="post" style="margin-top: 10px;">
                            <input type="hidden" name="id" value="<?php echo $message['id']; ?>">
                            <button type="submit">Mark as Read</button>
                        </form>
                    <?php else: ?>
                        <!-- Indicate that the message has already been read -->
                        <p style="color: green; font-weight: bold;">Status: Read</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
