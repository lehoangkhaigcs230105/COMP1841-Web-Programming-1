<?php
try{$pdo = new PDO('mysql:host=localhost;dbname=comp1841;charset=utf8mb4', 'root','');}
catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>