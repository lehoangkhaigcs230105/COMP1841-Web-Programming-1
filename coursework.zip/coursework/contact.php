<?php
include 'includes/DatabaseConnection.php'; // Ensure the database connection is included
session_start();

// Check if the user is logged in and has a valid session
if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect them to the login page
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['user_id'];

// Fetch the user's email from the database
$stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($user) {
    $user_email = $user['email'];
} else {
    // Handle error if the user is not found
    $feedback = "User email not found.";
    $user_email = ''; // Set to empty if email not found
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Ensure the email and message are not empty
    if (!empty($email) && !empty($message)) {
        // Prepare and insert the message into the user_messages table with the user ID
        $stmt = $pdo->prepare("INSERT INTO user_messages (user_id, email, message) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $email, $message]);

        // Provide feedback to the user that their message has been submitted
        $feedback = "Your message has been submitted successfully and will be reviewed by the admin.";

        // Optionally, send an email to the admin to notify them of the new message submission
        $to = 'admin@example.com';
        $subject = 'New Student Message';
        $admin_message = "A new message has been submitted by User ID: $user_id ($email).\n\nMessage: $message";
        $headers = 'From: no-reply@example.com';

        // Send the email to the admin
        // mail($to, $subject, $admin_message, $headers);
    } else {
        // If the email or message is empty, notify the user
        $feedback = "Please fill out all fields.";
    }
}

include 'C:\xampp\htdocs\coursework\templates\contact.html.php'; // Ensure the path to your template is correct
?>
