<?php
include 'includes/DatabaseConnection.php';

// Get the post ID from the URL parameters
$id = $_GET['id'];

// Begin a transaction to ensure data integrity
$pdo->beginTransaction();

try {
   

    // Now delete the post
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$id]);

    // Commit the transaction
    $pdo->commit();
    
    header("Location: index.php");
    exit();
} catch (Exception $e) {
    // Rollback the transaction on error
    $pdo->rollBack();
    echo "Error deleting record: " . $e->getMessage();
}
?>
